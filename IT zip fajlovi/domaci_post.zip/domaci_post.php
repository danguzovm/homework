<DOCTYPE HTML>
    <html lang="en">
    <head>
        <title></title>
    </head>
    <body>

    <form action="adresar_post.php" method="POST">
        <input type="text" name="ime" placeholder="Unesite ime">

        <button>Proveri</button>
    </form>
    </body>
    </html>